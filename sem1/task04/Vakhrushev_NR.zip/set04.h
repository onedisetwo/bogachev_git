#define EPS 1e-16
#define SUCCESS 0
#define ERROR_OPEN (-1)
#define ERROR_READ (-2)
#define EMPTY_FILE 1
double m_fabs(double);
int isEqual(double, double);