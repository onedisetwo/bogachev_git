#define EPS 1e-16
#define SUCCESS 0
#define ERROR_OPEN (-1)
#define ERROR_READ (-2)
#define EMPTY_FILE 1
#define WRONG_INPUT (-1)
int solution(const char *filename, int *res, int *i, int *j);
