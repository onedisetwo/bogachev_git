int print_bits (const char*);
int print_bits0 (const char*);
