int read_array(double* a, int n, const char* name);
void init_array(double *a, int n, int s);
void print_array(double *a, int n, int p);
