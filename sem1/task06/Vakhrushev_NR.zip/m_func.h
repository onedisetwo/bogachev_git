#define EPS 1e-16

double m_fabs(double x);
int is_equal(double a, double b);
int m_gcd(int a, int b);
