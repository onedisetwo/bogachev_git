enum all_constans{
    SUCCESS,
    ERROR_OPEN,
    ERROR_READ,
    ERROR_INIT,
    ERROR_VALUE,
    ERROR_DIVISION,
    ERROR_ZERO_D,
    ERROR_ALG,
    ERROR_UNKNOWN,
};