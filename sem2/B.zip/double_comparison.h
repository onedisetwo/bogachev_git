double get_eps(void);
double abs_value(double num);
int is_equal(double num_1, double num_2, double Eps);