#include "double_comparison.h"

double max_norm(double *a, int n, int m);
double sum_norm(double *a, int n, int m);
double sum_norm_deviation(double *a, double *x, double *b, int n);