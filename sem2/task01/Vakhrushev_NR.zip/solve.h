int solve1(const char *nameIn, const char *nameOut, const char *s, int *res);
int solve2(const char *nameIn, const char *nameOut, const char *s, int *res);
int solve3(const char *nameIn, const char *nameOut, const char *s, const char *t, int *res);
int solve4(const char *nameIn, const char *nameOut, const char *s, const char *t, int *res);
int solve5(const char *nameIn, const char *nameOut, const char *s, const char *t, int *res);
