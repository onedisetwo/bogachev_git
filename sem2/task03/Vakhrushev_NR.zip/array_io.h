void delete_array(char *a[], int n);

void print_array(char *a[], int n, int p);

int read_array(char *a[], int n, const char *filename);
