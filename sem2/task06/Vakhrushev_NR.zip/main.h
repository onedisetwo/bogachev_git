int get_k_name(int*, char**, int*, int, char**);
