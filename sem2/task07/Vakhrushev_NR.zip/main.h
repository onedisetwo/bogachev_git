int get_k_name(int*, char**, int*, int, char**);

int get_r2_task1(double *a, double *x, int n, double r1, double *r2);
	// may happen division by zero
int get_r1_task2_10(double *a, double *x, double *b, int n, double *r1);
	// May happen division by zero
void get_r2_task2_10(double *x, int n, double *r2);
void init_b(double *a, double *b, int n);
