int read_matrix(double *a, int n, int m, const char *filename);
void print_matrix(double *a, int n, int m, int p);

double f1(int, int, int, int);
double f2(int, int, int, int);
double f3(int, int, int, int);
double f4(int, int, int, int);
int init_matrix(double *a, int n, int m, int k);
