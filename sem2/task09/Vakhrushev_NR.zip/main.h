int get_k_name(int*, char**, int*, int, char**);

int read_data1_3(const char *filename, double *x, double *y, int n);
int read_data4(const char *filename, double *x, double *y, double *d, int n);
