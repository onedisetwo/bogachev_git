
double fu0(double x);

double fu1(double x);

double fu2(double x);

double fu3(double x);

double fu4(double x);

double fu5(double x);

double fu6(double x);

double fu0_(double x);

double fu1_(double x);

double fu2_(double x);

double fu3_(double x);

double fu4_(double x);

double fu5_(double x);

double fu6_(double x);

int getcount(void);
