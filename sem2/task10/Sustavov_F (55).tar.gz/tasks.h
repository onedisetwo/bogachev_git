
int task1(double (*op)(double), double a, double b, double ep, double *x);

int task2(double (*op)(double), double (*d)(double), double x0, double ep, double *x);

int task3(double (*op)(double), double a, double b, double ep, double *x);

int task4(double (*op)(double), double a, double b, double ep, double *x);

int task5(double (*op)(double), double a, double b, double ep, double *x);

int task6(double (*op)(double), int m, double *d, double a, double b, double ep, double *x);

int task7(double (*op)(double), double x0, double ep, double *x);

int task8(double (*op)(double), double a, double b, double ep, double *x);

int task9(double (*op)(double), double a, double b, double ep, double *x);

int task10(double (*op)(double), double a, double b, double ep, double *x);

double funk2(double* x, double* y, int n, double x0);

void quicksort_array(double *aa, double *bb, int lena);

int task3func(double *ma, double *bb, int len, double va);
