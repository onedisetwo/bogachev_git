int get_k_name(int*, char**, int*, int, char**);

double f0(double x);
double f1(double x);
double f2(double x);
double f3(double x);
double f4(double x);
double f5(double x);
double f6(double x);

/*
double d0(double x);
double d1(double x);
double d2(double x);
double d3(double x);
double d4(double x);
double d5(double x);
double d6(double x);
*/

int get_count(void);
