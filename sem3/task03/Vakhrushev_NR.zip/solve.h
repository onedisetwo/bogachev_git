#include "student.h"

int solve1(student*, int);
int solve2(student*, int);
int solve3(student*, int);
int solve4(student*, int);
int solve5(student*, int);
int solve6(student*, int, student* x);
int solve7(student*, int, student* x);
int solve8(student*, int, student* x);
int solve9(student*, int, student* x);
int solve10(student*, int, student* x);
